Calculates Interest

thats all it does
