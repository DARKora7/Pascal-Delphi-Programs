Compares two string.

Was just a test program to see if pascal was case sensitive.