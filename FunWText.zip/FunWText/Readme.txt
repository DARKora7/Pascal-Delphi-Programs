Mini search engine and string manipulation. 

searches available:
Zack
Wouter