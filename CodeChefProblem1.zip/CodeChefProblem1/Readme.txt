My attempt at a CodeChef Problem

the Winning solution found in Solutions Folder (The solution was written in C++ so I transcibed it into a working Pascal solution to show it to my class mates because it was relavant to the 
class work we were doing)