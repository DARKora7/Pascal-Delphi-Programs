Calculates colume of a cubes and Rectangular prisms

