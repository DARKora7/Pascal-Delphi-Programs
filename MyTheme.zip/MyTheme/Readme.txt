Demo Search engine made to practice formating and String manipulation and using Libruaries;

Searches available: 

Angel beats
guilty crown
tokyo ghoul
akame ga kill
berserk