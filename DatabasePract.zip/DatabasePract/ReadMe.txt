Practice Database Question for Exams
