Never compiled but deleted .exe should still work fine though
