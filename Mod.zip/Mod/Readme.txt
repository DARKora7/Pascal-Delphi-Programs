Returns The Modulo result of give integer.
